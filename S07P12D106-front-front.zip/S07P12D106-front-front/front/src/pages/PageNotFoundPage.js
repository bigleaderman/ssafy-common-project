import React from "react";
import { Container } from '../style.js';


const PageNotFoundPage = (props) => {
  return (
    <Container>
      <span>PageNotFoundPage</span>
    </Container>
  );
};

export default PageNotFoundPage;